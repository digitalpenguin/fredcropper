<?php
/**
 * @package fredcropper
 */
class FredCropperCrop extends xPDOSimpleObject {}
?>